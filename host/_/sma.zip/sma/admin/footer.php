    <footer>
         <div class="container">
         
            <div class="copy text-center">
               Copyright <?php echo date('Y'); ?> The Little Things
            </div>
            
         </div>
      </footer>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
	<script src="assets/js/jquery.validate.min.js" type="text/javascript"></script>
	<script src="sinch/sinch.min.js"></script>
    <script src="assets/js/webchat.js"></script>

	<script src="assets/js/custom.js"></script>
	
  </body>
</html>